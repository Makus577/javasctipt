(function() {

	var foo = 1;

	console.log(foo); // no-console
})();