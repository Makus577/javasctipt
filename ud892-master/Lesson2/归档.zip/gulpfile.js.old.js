var gulp = require('gulp');

gulp.task('default', function() {
	console.log('hello world!');
});
var 